import Foundation

enum OpportunityCategory: String, CaseIterable, Identifiable, Codable {
    case all = "All", roofing = "Roofing", extensions = "Extensions", lofts = "Lofts", newBuilds = "New Builds"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .all: return "scope"
        case .roofing: return "house.lodge.fill"
        case .extensions: return "hammer.fill"
        case .lofts: return "stairs"
        case .newBuilds: return "building.2.fill"
        }
    }
}

struct Opportunity: Identifiable, Hashable {
    let id: String
    let title, area, postcode: String
    let distanceMiles: Double
    let category: OpportunityCategory
    let score: Int
    let status, discovered, estimatedValue, description: String
    let likelyWork, reasons: [String]
    let reference, source: String
    let sourceURL: String?
    let receivedAt: Date?
}
