import Foundation
import Combine
import UserNotifications

private struct ArcGISResponse: Decodable {
    let features: [ArcGISFeature]?
    let error: ArcGISError?
}

private struct ArcGISError: Decodable {
    let message: String
}

private struct ArcGISFeature: Decodable {
    let attributes: ArcGISAttributes
    let geometry: ArcGISGeometry?
}

private struct ArcGISAttributes: Decodable {
    let KEYVAL: String?
    let REFVAL: String?
    let DCSTAT: String?
    let DECSN: String?
    let DATEAPRECV: Double?
    let DATEAPVAL: Double?
    let DATEDECISN: Double?
    let ADDRESS: String?
    let PROPOSAL: String?
    let PA_LINK: String?
}

private struct ArcGISGeometry: Decodable {
    let rings: [[[Double]]]?
}

@MainActor
final class OpportunityStore: ObservableObject {
    @Published var opportunities: [Opportunity] = []
    @Published var savedIDs: Set<String> = []
    @Published var category: OpportunityCategory = .all
    @Published var searchText = ""
    @Published var radius = 15.0
    @Published var isScanning = false
    @Published var scanMessage = "Ready to scan live Bradford planning data"
    @Published var notificationsEnabled = false
    @Published var feedIsLive = false
    @Published var lastUpdated: Date?
    @Published var lastError: String?
    @Published var filteredOutCount = 0

    private let sourceName = "Bradford Council Planning Applications"
    private let endpoint = "https://gis.bradford.gov.uk/server/rest/services/Open_Data/Planning_Applications/MapServer/0/query"
    private let bradfordLatitude = 53.7950
    private let bradfordLongitude = -1.7594
    private let savedKey = "zkRadar.savedRefs.v2"

    init() {
        savedIDs = Set(UserDefaults.standard.stringArray(forKey: savedKey) ?? [])
        Task { await refreshNotificationState() }
    }

    var filtered: [Opportunity] {
        opportunities
            .filter { category == .all || $0.category == category }
            .filter { $0.distanceMiles <= radius }
            .filter {
                searchText.isEmpty ||
                $0.title.localizedCaseInsensitiveContains(searchText) ||
                $0.area.localizedCaseInsensitiveContains(searchText) ||
                $0.postcode.localizedCaseInsensitiveContains(searchText) ||
                $0.reference.localizedCaseInsensitiveContains(searchText)
            }
            .sorted { lhs, rhs in
                if lhs.score == rhs.score { return (lhs.receivedAt ?? .distantPast) > (rhs.receivedAt ?? .distantPast) }
                return lhs.score > rhs.score
            }
    }

    var saved: [Opportunity] {
        opportunities.filter { savedIDs.contains($0.id) }.sorted { $0.score > $1.score }
    }

    var highScoreCount: Int { filtered.filter { $0.score >= 85 }.count }

    var potentialValueText: String {
        let count = filtered.count
        guard count > 0 else { return "£0" }
        let rough = filtered.reduce(0) { partial, item in partial + midpointValue(for: item.category) }
        if rough >= 1_000_000 { return String(format: "£%.1fm", Double(rough) / 1_000_000.0) }
        return "£\(rough / 1000)k+"
    }

    func toggleSaved(_ item: Opportunity) {
        if savedIDs.contains(item.id) { savedIDs.remove(item.id) } else { savedIDs.insert(item.id) }
        UserDefaults.standard.set(Array(savedIDs), forKey: savedKey)
    }

    func scan() async {
        guard !isScanning else { return }
        isScanning = true
        lastError = nil
        scanMessage = "Connecting to Bradford Council…"

        do {
            let previousIDs = Set(opportunities.map(\.id))
            let result = try await fetchLiveApplications()
            scanMessage = "Filtering for high-probability roofing leads…"
            try? await Task.sleep(for: .milliseconds(220))
            opportunities = result.qualified
            filteredOutCount = result.filteredOut
            feedIsLive = true
            lastUpdated = Date()
            scanMessage = result.qualified.isEmpty
                ? "Live feed connected · no qualified leads right now"
                : "\(result.qualified.count) qualified leads kept · \(result.filteredOut) weak matches removed"
            await notifyForNewHighScores(in: result.qualified.filter { !previousIDs.contains($0.id) })
        } catch {
            feedIsLive = false
            lastError = error.localizedDescription
            scanMessage = "Live scan failed · tap to retry"
        }

        isScanning = false
    }

    private func fetchLiveApplications() async throws -> (qualified: [Opportunity], filteredOut: Int) {
        guard var components = URLComponents(string: endpoint) else { throw URLError(.badURL) }
        components.queryItems = [
            URLQueryItem(name: "where", value: "1=1"),
            URLQueryItem(name: "outFields", value: "KEYVAL,REFVAL,DCSTAT,DECSN,DATEAPRECV,DATEAPVAL,DATEDECISN,ADDRESS,PROPOSAL,PA_LINK"),
            URLQueryItem(name: "orderByFields", value: "DATEAPRECV DESC"),
            URLQueryItem(name: "resultRecordCount", value: "500"),
            URLQueryItem(name: "returnGeometry", value: "true"),
            URLQueryItem(name: "outSR", value: "4326"),
            URLQueryItem(name: "f", value: "json")
        ]
        guard let url = components.url else { throw URLError(.badURL) }

        var request = URLRequest(url: url)
        request.timeoutInterval = 25
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("ZK Opportunity Radar/0.2.1 iOS", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        let payload = try JSONDecoder().decode(ArcGISResponse.self, from: data)
        if let apiError = payload.error { throw NSError(domain: "BradfordGIS", code: 1, userInfo: [NSLocalizedDescriptionKey: apiError.message]) }

        let features = payload.features ?? []
        let candidates = features.compactMap(makeOpportunity(from:))
        let qualified = candidates
            .filter { $0.distanceMiles <= 30 }
            .filter(isQualifiedLead)
            .sorted {
                if $0.score == $1.score { return ($0.receivedAt ?? .distantPast) > ($1.receivedAt ?? .distantPast) }
                return $0.score > $1.score
            }
            .prefix(100)

        let kept = Array(qualified)
        return (kept, max(0, features.count - kept.count))
    }

    private func makeOpportunity(from feature: ArcGISFeature) -> Opportunity? {
        let a = feature.attributes
        let proposal = clean(a.PROPOSAL)
        let address = clean(a.ADDRESS)
        guard !proposal.isEmpty, !address.isEmpty else { return nil }

        let category = classify(proposal)
        guard isRelevant(proposal, category: category) else { return nil }

        let reference = clean(a.REFVAL).isEmpty ? clean(a.KEYVAL) : clean(a.REFVAL)
        guard !reference.isEmpty else { return nil }

        let received = date(fromMilliseconds: a.DATEAPRECV)
        let decisionDate = date(fromMilliseconds: a.DATEDECISN)
        let coord = centroid(feature.geometry)
        let distance = coord.map { haversineMiles(lat1: bradfordLatitude, lon1: bradfordLongitude, lat2: $0.lat, lon2: $0.lon) } ?? 0
        let postcode = extractPostcode(from: address)
        let area = extractArea(from: address, postcode: postcode)
        let status = statusText(decision: a.DECSN, decisionDate: decisionDate)
        let work = likelyWork(for: proposal, category: category)
        let scoreResult = score(proposal: proposal, category: category, status: status, received: received, distance: distance)

        return Opportunity(
            id: reference,
            title: proposal,
            area: area,
            postcode: postcode,
            distanceMiles: distance,
            category: category,
            score: scoreResult.value,
            status: status,
            discovered: relativeDate(received),
            estimatedValue: estimatedValue(for: category, proposal: proposal),
            description: proposal,
            likelyWork: work,
            reasons: scoreResult.reasons,
            reference: reference,
            source: sourceName,
            sourceURL: normalizedSourceURL(a.PA_LINK, key: a.KEYVAL),
            receivedAt: received
        )
    }

    private func isRelevant(_ proposal: String, category: OpportunityCategory) -> Bool {
        let s = proposal.lowercased()
        let strong = ["roof", "dormer", "loft", "extension", "dwelling", "house", "bungalow", "garage", "solar", "chimney", "tiles", "slate", "canopy", "porch", "annexe", "outbuilding"]
        return strong.contains { s.contains($0) } || category != .roofing
    }

    private func classify(_ proposal: String) -> OpportunityCategory {
        let s = proposal.lowercased()
        if s.contains("loft") || s.contains("dormer") || s.contains("hip to gable") || s.contains("hip-to-gable") { return .lofts }
        if s.contains("new dwelling") || s.contains("new build") || s.contains("erection of") && (s.contains("dwelling") || s.contains("house") || s.contains("bungalow")) { return .newBuilds }
        if s.contains("extension") || s.contains("porch") || s.contains("annexe") { return .extensions }
        return .roofing
    }

    private func score(proposal: String, category: OpportunityCategory, status: String, received: Date?, distance: Double) -> (value: Int, reasons: [String]) {
        let s = proposal.lowercased()
        var value = 28
        var reasons: [String] = []

        let reroofTerms = ["re-roof", "reroof", "replacement roof", "replace roof", "roof coverings", "roof covering", "new roof"]
        let roofTerms = ["roof", "slate", "tile", "leadwork", "flashing", "chimney", "gutter", "fascia", "soffit", "rooflight", "roof light"]
        let explicitReroof = reroofTerms.contains { s.contains($0) }
        let roofMatches = roofTerms.filter { s.contains($0) }

        if explicitReroof { value += 34; reasons.append("Explicit re-roof / roof replacement scope") }
        else if !roofMatches.isEmpty { value += min(26, 10 + roofMatches.count * 4); reasons.append("Direct roofing scope in proposal") }

        if category == .lofts { value += 23; reasons.append("Loft/dormer conversion creates a strong roof package") }
        if category == .extensions { value += 16; reasons.append("Extension likely requires new roof works") }
        if category == .newBuilds { value += 18; reasons.append("New-build project includes a complete roof package") }

        if status == "Approved" { value += 10; reasons.append("Planning appears approved") }
        else if status == "Submitted" { value += 5; reasons.append("Fresh application still in the buying window") }

        if let received {
            let days = max(0, Calendar.current.dateComponents([.day], from: received, to: Date()).day ?? 999)
            if days <= 7 { value += 16; reasons.append("Received within the last 7 days") }
            else if days <= 30 { value += 11; reasons.append("Received within the last 30 days") }
            else if days <= 60 { value += 6; reasons.append("Still relatively recent") }
            else if days > 120 { value -= 18 }
        }

        if distance <= 5 { value += 8; reasons.append("Very local to Bradford") }
        else if distance <= 15 { value += 5; reasons.append("Inside the core service radius") }
        else if distance > 20 { value -= 6 }

        if s.contains("retrospective") { value -= 12 }
        if s.contains("discharge of condition") || s.contains("non material amendment") || s.contains("non-material amendment") { value -= 20 }

        return (min(99, max(20, value)), Array(reasons.prefix(5)))
    }

    private func isQualifiedLead(_ item: Opportunity) -> Bool {
        let s = item.description.lowercased()
        let rejectedStatuses = ["Refused", "Withdrawn", "Invalid"]
        guard !rejectedStatuses.contains(item.status) else { return false }
        guard item.score >= 76 else { return false }

        if let received = item.receivedAt {
            let days = Calendar.current.dateComponents([.day], from: received, to: Date()).day ?? 999
            guard days <= 120 else { return false }
        }

        let explicitRoof = ["roof", "re-roof", "reroof", "slate", "tile", "dormer", "loft", "chimney", "leadwork", "flashing", "rooflight", "roof light"].contains { s.contains($0) }
        let strongProject = item.category == .newBuilds || item.category == .extensions || item.category == .lofts
        guard explicitRoof || strongProject else { return false }

        let lowValueAdmin = ["discharge of condition", "non material amendment", "non-material amendment", "variation of condition", "certificate of lawful", "lawful development certificate", "advertisement", "tree works"]
        guard !lowValueAdmin.contains(where: { s.contains($0) }) else { return false }
        return true
    }

    private func likelyWork(for proposal: String, category: OpportunityCategory) -> [String] {
        let s = proposal.lowercased()
        var work: [String] = []
        func add(_ condition: Bool, _ text: String) { if condition && !work.contains(text) { work.append(text) } }
        add(s.contains("dormer"), "Dormer roof and weathering")
        add(s.contains("rooflight") || s.contains("roof light"), "Rooflight installation")
        add(s.contains("slate"), "Slate roofing")
        add(s.contains("tile"), "Tiled roofing")
        add(s.contains("chimney"), "Chimney / leadwork")
        add(s.contains("solar"), "Solar roof integration")
        add(s.contains("flat roof"), "Flat-roof system")
        add(s.contains("pitched roof"), "Pitched roof")
        if work.isEmpty {
            switch category {
            case .lofts: work = ["Roof alteration", "Weathering / flashing", "Insulation"]
            case .extensions: work = ["Extension roof", "Fascia / guttering", "Leadwork"]
            case .newBuilds: work = ["Complete roof package", "Rainwater system", "Roof coverings"]
            default: work = ["Roofing works", "Flashings / weathering", "Rainwater goods"]
            }
        }
        return Array(work.prefix(4))
    }

    private func estimatedValue(for category: OpportunityCategory, proposal: String) -> String {
        let s = proposal.lowercased()
        if category == .newBuilds {
            if s.contains("dwellings") || s.contains("houses") || s.contains("apartments") { return "£250k–£1m+" }
            return "£120k–£300k"
        }
        if category == .lofts { return "£30k–£70k" }
        if category == .extensions {
            if s.contains("two storey") || s.contains("two-storey") { return "£60k–£140k" }
            return "£25k–£80k"
        }
        if s.contains("replacement roof") || s.contains("re-roof") || s.contains("reroof") { return "£8k–£30k" }
        return "£5k–£35k"
    }

    private func midpointValue(for category: OpportunityCategory) -> Int {
        switch category {
        case .newBuilds: return 210_000
        case .lofts: return 50_000
        case .extensions: return 55_000
        case .roofing, .all: return 20_000
        }
    }

    private func statusText(decision: String?, decisionDate: Date?) -> String {
        let s = clean(decision).uppercased()
        if s.contains("REFUS") || s.contains("DECLIN") || s.contains("DISMISS") { return "Refused" }
        if s.contains("WITHDRAW") { return "Withdrawn" }
        if s.contains("INVALID") { return "Invalid" }
        if s.contains("GRANT") || s.contains("APPROV") || s.contains("PERMIT") { return "Approved" }
        if decisionDate != nil { return "Decided" }
        return "Submitted"
    }

    private func clean(_ value: String?) -> String {
        (value ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func date(fromMilliseconds value: Double?) -> Date? {
        guard let value, value > 0 else { return nil }
        return Date(timeIntervalSince1970: value / 1000.0)
    }

    private func relativeDate(_ date: Date?) -> String {
        guard let date else { return "Live feed" }
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .short
        return formatter.localizedString(for: date, relativeTo: Date())
    }

    private func extractPostcode(from address: String) -> String {
        let pattern = #"\b(?:BD|LS|HX)\d{1,2}[A-Z]?\s*\d[A-Z]{2}\b"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else { return "Bradford" }
        let range = NSRange(address.startIndex..., in: address)
        guard let match = regex.firstMatch(in: address, range: range), let swiftRange = Range(match.range, in: address) else { return "Bradford" }
        return String(address[swiftRange]).uppercased()
    }

    private func extractArea(from address: String, postcode: String) -> String {
        let parts = address.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        if parts.count >= 2 {
            let candidate = parts[parts.count - 2]
            if candidate.count <= 30 { return candidate }
        }
        if postcode.hasPrefix("BD18") || postcode.hasPrefix("BD17") { return "Shipley" }
        if postcode.hasPrefix("BD16") { return "Bingley" }
        if postcode.hasPrefix("BD20") || postcode.hasPrefix("BD21") || postcode.hasPrefix("BD22") { return "Keighley" }
        return "Bradford"
    }

    private func normalizedSourceURL(_ raw: String?, key: String?) -> String? {
        let candidate = clean(raw)
        if candidate.hasPrefix("http://") || candidate.hasPrefix("https://") { return candidate }
        let k = clean(key)
        guard !k.isEmpty else { return nil }
        let encoded = k.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? k
        return "https://planning.bradford.gov.uk/online-applications/applicationDetails.do?keyVal=\(encoded)&activeTab=summary"
    }

    private func centroid(_ geometry: ArcGISGeometry?) -> (lat: Double, lon: Double)? {
        guard let ring = geometry?.rings?.first, !ring.isEmpty else { return nil }
        let valid = ring.filter { $0.count >= 2 }
        guard !valid.isEmpty else { return nil }
        let lon = valid.reduce(0.0) { $0 + $1[0] } / Double(valid.count)
        let lat = valid.reduce(0.0) { $0 + $1[1] } / Double(valid.count)
        return (lat, lon)
    }

    private func haversineMiles(lat1: Double, lon1: Double, lat2: Double, lon2: Double) -> Double {
        let r = 3958.7613
        let p1 = lat1 * .pi / 180
        let p2 = lat2 * .pi / 180
        let dp = (lat2 - lat1) * .pi / 180
        let dl = (lon2 - lon1) * .pi / 180
        let a = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    func requestNotifications() async {
        do {
            notificationsEnabled = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
        } catch { notificationsEnabled = false }
    }

    private func refreshNotificationState() async {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        notificationsEnabled = settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional
    }

    private func notifyForNewHighScores(in items: [Opportunity]) async {
        guard notificationsEnabled else { return }
        for item in items.filter({ $0.score >= 85 }).prefix(3) {
            let content = UNMutableNotificationContent()
            content.title = "ZK Radar · \(item.score) score"
            content.body = "\(item.title) · \(item.area)"
            content.sound = .default
            try? await UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "radar-\(item.id)", content: content, trigger: nil))
        }
    }

    func propertyOwnerLetter(for item: Opportunity) -> String {
        """
        Dear Property Owner,

        We are contacting you regarding the publicly listed planning application \(item.reference) concerning \(item.title.lowercased()) in \(item.postcode).

        We are a local roofing contractor serving \(item.area) and the surrounding area. Based on the published proposal, the work may involve \(item.likelyWork.joined(separator: ", ").lowercased()).

        If you are currently obtaining quotations and have not yet appointed a roofing contractor, we would be happy to discuss the roofing element and provide a no-obligation quotation.

        If this is not relevant, please disregard this letter.

        Kind regards,
        [Roofing company name]
        [Telephone number]
        [Email / website]
        """
    }

    func rooferSalesMessage(for item: Opportunity) -> String {
        """
        Hi,

        I run ZK Opportunity Radar, which monitors newly published local planning applications and filters them for roofing opportunities.

        I found a high-probability lead in \(item.area) (\(item.postcode)):
        • ZK score: \(item.score)/99
        • Planning ref: \(item.reference)
        • Proposal: \(item.title)
        • Likely roofing work: \(item.likelyWork.joined(separator: ", "))
        • Status: \(item.status)

        I can send you qualified local opportunities like this without you having to search planning portals manually.

        If you want, I can send a couple of current examples first and you can decide whether the service is useful.

        Regards,
        ZK Opportunity Radar
        [Your name / contact details]
        """
    }
}
