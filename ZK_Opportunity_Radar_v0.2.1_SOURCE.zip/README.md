# ZK Opportunity Radar v0.2.0 LIVE

Native iPhone build connected directly to Bradford Council's public Planning Applications ArcGIS REST service. The app pulls live planning records, ranks roofing/extension/loft/new-build opportunities locally, supports radius/category/search filters, saved records, high-score notifications, council-record links and an introduction-letter generator.

## What is live
- Planning application proposal, address, reference, application/decision dates and source link come from Bradford Council's public planning dataset.
- The feed is refreshed from the council service when the app launches and whenever **Scan Now** is tapped.
- Council open-data publishing is currently updated on a daily cycle, so "live" means the latest records currently exposed by that official feed rather than second-by-second data.

## What ZK estimates
- Opportunity score
- Likely roofing work
- Approximate project-value range
- Category classification

These are local heuristics for lead prioritisation and are not council-provided facts or guaranteed contract values. Always open the council record and verify the application before outreach.

## Build and install
1. Upload this source to GitHub.
2. Open **Actions → Build ZK Opportunity Radar IPA → Run workflow**.
3. Download the `ZK-Opportunity-Radar-v0.2.0` artifact.
4. Extract `ZK_Opportunity_Radar_v0.2.0.ipa`.
5. Install with SideStore.

Bundle ID remains `com.zk.opportunityradar`, so v0.2.0 updates the existing Radar install.
