import Foundation
import Combine
import UserNotifications

private struct ArcGISResponse: Decodable { let features: [ArcGISFeature]?; let error: ArcGISError? }
private struct ArcGISError: Decodable { let message: String }
private struct ArcGISFeature: Decodable { let attributes: ArcGISAttributes; let geometry: ArcGISGeometry? }
private struct ArcGISAttributes: Decodable {
    let KEYVAL: String?; let REFVAL: String?; let DCSTAT: String?; let DECSN: String?
    let DATEAPRECV: Double?; let DATEAPVAL: Double?; let DATEDECISN: Double?
    let ADDRESS: String?; let PROPOSAL: String?; let PA_LINK: String?
}
private struct ArcGISGeometry: Decodable { let rings: [[[Double]]]? }

private struct PlanningDataResponse: Decodable {
    let entities: [PlanningDataEntity]
}
private struct PlanningDataEntity: Decodable {
    let entity: Int?
    let reference: String?
    let description: String?
    let addressText: String?
    let startDate: String?
    let decisionDate: String?
    let planningDecision: String?
    let documentationURL: String?
    let point: String?
    let organisationEntity: Int?
    enum CodingKeys: String, CodingKey {
        case entity, reference, description, point
        case addressText = "address-text"
        case startDate = "start-date"
        case decisionDate = "decision-date"
        case planningDecision = "planning-decision"
        case documentationURL = "documentation-url"
        case organisationEntity = "organisation-entity"
    }
}

@MainActor
final class OpportunityStore: ObservableObject {
    @Published var opportunities: [Opportunity] = []
    @Published var savedIDs: Set<String> = []
    @Published var category: OpportunityCategory = .all
    @Published var searchText = ""
    @Published var radius = 45.0
    @Published var isScanning = false
    @Published var scanMessage = "Ready to scan West Yorkshire"
    @Published var notificationsEnabled = false
    @Published var feedIsLive = false
    @Published var lastUpdated: Date?
    @Published var lastError: String?
    @Published var filteredOutCount = 0
    @Published var sourceSummary = "West Yorkshire public planning feeds"

    private let bradfordEndpoint = "https://gis.bradford.gov.uk/server/rest/services/Open_Data/Planning_Applications/MapServer/0/query"
    private let planningDataEndpoint = "https://www.planning.data.gov.uk/entity.json"
    private let centreLatitude = 53.7997
    private let centreLongitude = -1.5492
    private let savedKey = "zkRadar.savedRefs.v3"

    init() {
        savedIDs = Set(UserDefaults.standard.stringArray(forKey: savedKey) ?? [])
        Task { await refreshNotificationState() }
    }

    var filtered: [Opportunity] {
        opportunities
            .filter { category == .all || $0.category == category }
            .filter { $0.distanceMiles <= radius }
            .filter {
                searchText.isEmpty || $0.title.localizedCaseInsensitiveContains(searchText) ||
                $0.area.localizedCaseInsensitiveContains(searchText) || $0.city.localizedCaseInsensitiveContains(searchText) ||
                $0.postcode.localizedCaseInsensitiveContains(searchText) || $0.reference.localizedCaseInsensitiveContains(searchText)
            }
            .sorted { lhs, rhs in
                if lhs.score == rhs.score { return (lhs.receivedAt ?? .distantPast) > (rhs.receivedAt ?? .distantPast) }
                return lhs.score > rhs.score
            }
    }

    var saved: [Opportunity] { opportunities.filter { savedIDs.contains($0.id) }.sorted { $0.score > $1.score } }
    var highScoreCount: Int { filtered.filter { $0.score >= 85 }.count }
    var citiesCovered: [String] { Array(Set(opportunities.map(\.city))).sorted() }

    var potentialValueText: String {
        guard !filtered.isEmpty else { return "£0" }
        let rough = filtered.reduce(0) { $0 + midpointValue(for: $1.category) }
        if rough >= 1_000_000 { return String(format: "£%.1fm", Double(rough) / 1_000_000.0) }
        return "£\(rough / 1000)k+"
    }

    func toggleSaved(_ item: Opportunity) {
        if savedIDs.contains(item.id) { savedIDs.remove(item.id) } else { savedIDs.insert(item.id) }
        UserDefaults.standard.set(Array(savedIDs), forKey: savedKey)
    }

    func scan() async {
        guard !isScanning else { return }
        isScanning = true; lastError = nil; scanMessage = "Scanning West Yorkshire public planning data…"
        do {
            let previousIDs = Set(opportunities.map(\.id))
            async let national = fetchPlanningDataWestYorkshire()
            async let bradford = fetchBradfordApplications()
            let (nationalItems, bradfordItems) = try await (national, bradford)
            scanMessage = "Removing stale, assigned and weak roofing matches…"
            let merged = deduplicate(nationalItems + bradfordItems)
            let qualified = merged.filter(isQualifiedLead).sorted {
                if $0.score == $1.score { return ($0.receivedAt ?? .distantPast) > ($1.receivedAt ?? .distantPast) }
                return $0.score > $1.score
            }
            opportunities = Array(qualified.prefix(150))
            filteredOutCount = max(0, merged.count - opportunities.count)
            feedIsLive = true; lastUpdated = Date()
            sourceSummary = "Planning Data (England) + Bradford Council GIS"
            scanMessage = opportunities.isEmpty ? "Live feeds connected · no qualified unassigned roofing leads" : "\(opportunities.count) qualified leads · \(citiesCovered.count) West Yorkshire areas"
            await notifyForNewHighScores(in: opportunities.filter { !previousIDs.contains($0.id) })
        } catch {
            feedIsLive = false; lastError = error.localizedDescription; scanMessage = "Live scan failed · tap to retry"
        }
        isScanning = false
    }

    private func fetchPlanningDataWestYorkshire() async throws -> [Opportunity] {
        guard var components = URLComponents(string: planningDataEndpoint) else { throw URLError(.badURL) }
        let since = Calendar.current.date(byAdding: .day, value: -75, to: Date()) ?? Date()
        let dc = Calendar.current.dateComponents([.year,.month,.day], from: since)
        let polygon = "POLYGON((-2.20 53.52,-1.10 53.52,-1.10 54.05,-2.20 54.05,-2.20 53.52))"
        components.queryItems = [
            URLQueryItem(name: "dataset", value: "planning-application"),
            URLQueryItem(name: "start_date_year", value: String(dc.year ?? 2026)),
            URLQueryItem(name: "start_date_month", value: String(dc.month ?? 1)),
            URLQueryItem(name: "start_date_day", value: String(dc.day ?? 1)),
            URLQueryItem(name: "start_date_match", value: "since"),
            URLQueryItem(name: "geometry", value: polygon),
            URLQueryItem(name: "geometry_relation", value: "intersects"),
            URLQueryItem(name: "limit", value: "500"),
            URLQueryItem(name: "offset", value: "0")
        ]
        guard let url = components.url else { throw URLError(.badURL) }
        var request = URLRequest(url: url); request.timeoutInterval = 30; request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("ZK Opportunity Radar/0.3.0 iOS", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw URLError(.badServerResponse) }
        let payload = try JSONDecoder().decode(PlanningDataResponse.self, from: data)
        return payload.entities.compactMap(makeOpportunity(fromPlanningData:))
    }

    private func fetchBradfordApplications() async throws -> [Opportunity] {
        guard var components = URLComponents(string: bradfordEndpoint) else { throw URLError(.badURL) }
        components.queryItems = [
            URLQueryItem(name: "where", value: "1=1"),
            URLQueryItem(name: "outFields", value: "KEYVAL,REFVAL,DCSTAT,DECSN,DATEAPRECV,DATEAPVAL,DATEDECISN,ADDRESS,PROPOSAL,PA_LINK"),
            URLQueryItem(name: "orderByFields", value: "DATEAPRECV DESC"),
            URLQueryItem(name: "resultRecordCount", value: "500"),
            URLQueryItem(name: "returnGeometry", value: "true"),
            URLQueryItem(name: "outSR", value: "4326"),
            URLQueryItem(name: "f", value: "json")
        ]
        guard let url = components.url else { throw URLError(.badURL) }
        var request = URLRequest(url: url); request.timeoutInterval = 25; request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("ZK Opportunity Radar/0.3.0 iOS", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw URLError(.badServerResponse) }
        let payload = try JSONDecoder().decode(ArcGISResponse.self, from: data)
        if let apiError = payload.error { throw NSError(domain: "BradfordGIS", code: 1, userInfo: [NSLocalizedDescriptionKey: apiError.message]) }
        return (payload.features ?? []).compactMap(makeOpportunity(fromBradford:))
    }

    private func makeOpportunity(fromPlanningData item: PlanningDataEntity) -> Opportunity? {
        let proposal = clean(item.description), address = clean(item.addressText), reference = clean(item.reference)
        guard !proposal.isEmpty, !address.isEmpty, !reference.isEmpty else { return nil }
        let postcode = extractPostcode(from: address)
        guard isWestYorkshirePostcode(postcode) else { return nil }
        let category = classify(proposal); guard isRelevant(proposal, category: category), contractorAppearsUnassigned(proposal) else { return nil }
        let received = parseISODate(item.startDate); let decision = parseISODate(item.decisionDate)
        let coord = pointCoordinate(item.point)
        let distance = coord.map { haversineMiles(lat1: centreLatitude, lon1: centreLongitude, lat2: $0.lat, lon2: $0.lon) } ?? 0
        let city = cityFor(postcode: postcode, address: address)
        let status = statusText(decision: item.planningDecision, decisionDate: decision)
        let scoreResult = score(proposal: proposal, category: category, status: status, received: received, decision: decision, city: city)
        return Opportunity(id: "PD-\(item.entity ?? 0)-\(reference)", title: proposal, area: extractArea(from: address, postcode: postcode), postcode: postcode, city: city, distanceMiles: distance, category: category, score: scoreResult.value, status: status, discovered: relativeDate(received), estimatedValue: estimatedValue(for: category, proposal: proposal), description: proposal, likelyWork: likelyWork(for: proposal, category: category), reasons: scoreResult.reasons, reference: reference, source: "Planning Data · GOV.UK", sourceURL: item.documentationURL, receivedAt: received, decisionAt: decision, latitude: coord?.lat, longitude: coord?.lon, contractorCheck: "No contractor named in public application summary")
    }

    private func makeOpportunity(fromBradford feature: ArcGISFeature) -> Opportunity? {
        let a = feature.attributes, proposal = clean(a.PROPOSAL), address = clean(a.ADDRESS)
        guard !proposal.isEmpty, !address.isEmpty, contractorAppearsUnassigned(proposal) else { return nil }
        let category = classify(proposal); guard isRelevant(proposal, category: category) else { return nil }
        let reference = clean(a.REFVAL).isEmpty ? clean(a.KEYVAL) : clean(a.REFVAL); guard !reference.isEmpty else { return nil }
        let received = date(fromMilliseconds: a.DATEAPRECV), decision = date(fromMilliseconds: a.DATEDECISN)
        let coord = centroid(feature.geometry); let distance = coord.map { haversineMiles(lat1: centreLatitude, lon1: centreLongitude, lat2: $0.lat, lon2: $0.lon) } ?? 0
        let postcode = extractPostcode(from: address), city = cityFor(postcode: postcode, address: address)
        let status = statusText(decision: a.DECSN, decisionDate: decision)
        let scoreResult = score(proposal: proposal, category: category, status: status, received: received, decision: decision, city: city)
        return Opportunity(id: "BR-\(reference)", title: proposal, area: extractArea(from: address, postcode: postcode), postcode: postcode, city: city, distanceMiles: distance, category: category, score: scoreResult.value, status: status, discovered: relativeDate(received), estimatedValue: estimatedValue(for: category, proposal: proposal), description: proposal, likelyWork: likelyWork(for: proposal, category: category), reasons: scoreResult.reasons, reference: reference, source: "Bradford Council Planning Applications", sourceURL: normalizedBradfordURL(a.PA_LINK, key: a.KEYVAL), receivedAt: received, decisionAt: decision, latitude: coord?.lat, longitude: coord?.lon, contractorCheck: "No contractor named in public application summary")
    }

    private func deduplicate(_ items: [Opportunity]) -> [Opportunity] {
        var seen = Set<String>(); var output: [Opportunity] = []
        for item in items.sorted(by: { $0.score > $1.score }) {
            let key = "\(item.reference.lowercased())|\(item.postcode.replacingOccurrences(of: " ", with: ""))"
            if seen.insert(key).inserted { output.append(item) }
        }
        return output
    }

    private func contractorAppearsUnassigned(_ proposal: String) -> Bool {
        let s = proposal.lowercased()
        let assigned = ["appointed contractor", "main contractor", "roofing contractor", "building contractor", "contractor:", "contractor -", "works by ", "builder:", "builder -", "construction contractor"]
        return !assigned.contains(where: { s.contains($0) })
    }

    private func isQualifiedLead(_ item: Opportunity) -> Bool {
        let s = item.description.lowercased(); guard item.score >= 78 else { return false }
        guard !["Refused","Withdrawn","Invalid","Decided"].contains(item.status) else { return false }
        guard contractorAppearsUnassigned(s) else { return false }
        if let received = item.receivedAt {
            let age = Calendar.current.dateComponents([.day], from: received, to: Date()).day ?? 999
            if item.status == "Submitted" { guard age <= 60 else { return false } }
            else { guard age <= 90 else { return false } }
        }
        if item.status == "Approved", let d = item.decisionAt {
            let daysSinceDecision = Calendar.current.dateComponents([.day], from: d, to: Date()).day ?? 999
            guard daysSinceDecision <= 45 else { return false }
        }
        let directRoof = ["roof","re-roof","reroof","slate","tile","dormer","loft","chimney","leadwork","flashing","rooflight","roof light"].contains { s.contains($0) }
        let strongProject = item.category == .newBuilds || item.category == .extensions || item.category == .lofts
        guard directRoof || strongProject else { return false }
        let admin = ["discharge of condition","non material amendment","non-material amendment","variation of condition","certificate of lawful","lawful development certificate","advertisement","tree works","prior notification","reserved matters only"]
        return !admin.contains(where: { s.contains($0) })
    }

    private func isRelevant(_ proposal: String, category: OpportunityCategory) -> Bool {
        let s = proposal.lowercased()
        let terms = ["roof","dormer","loft","extension","dwelling","house","bungalow","garage","solar","chimney","tiles","slate","canopy","porch","annexe","outbuilding"]
        return terms.contains { s.contains($0) } || category != .roofing
    }

    private func classify(_ proposal: String) -> OpportunityCategory {
        let s = proposal.lowercased()
        if s.contains("loft") || s.contains("dormer") || s.contains("hip to gable") || s.contains("hip-to-gable") { return .lofts }
        if s.contains("new dwelling") || s.contains("new build") || (s.contains("erection of") && (s.contains("dwelling") || s.contains("house") || s.contains("bungalow"))) { return .newBuilds }
        if s.contains("extension") || s.contains("porch") || s.contains("annexe") { return .extensions }
        return .roofing
    }

    private func score(proposal: String, category: OpportunityCategory, status: String, received: Date?, decision: Date?, city: String) -> (value: Int, reasons: [String]) {
        let s = proposal.lowercased(); var value = 30; var reasons: [String] = []
        let reroof = ["re-roof","reroof","replacement roof","replace roof","roof coverings","new roof"].contains { s.contains($0) }
        let roofMatches = ["roof","slate","tile","leadwork","flashing","chimney","gutter","fascia","soffit","rooflight","roof light"].filter { s.contains($0) }
        if reroof { value += 34; reasons.append("Explicit roof replacement scope") }
        else if !roofMatches.isEmpty { value += min(26, 10 + roofMatches.count * 4); reasons.append("Direct roofing scope") }
        if category == .lofts { value += 23; reasons.append("Loft/dormer creates a strong roof package") }
        if category == .extensions { value += 17; reasons.append("Extension likely requires new roofing") }
        if category == .newBuilds { value += 19; reasons.append("Complete new-build roof package") }
        if status == "Approved" { value += 9; reasons.append("Recently approved / buying window") }
        if status == "Submitted" { value += 8; reasons.append("Still early in planning process") }
        if let received {
            let days = max(0, Calendar.current.dateComponents([.day], from: received, to: Date()).day ?? 999)
            if days <= 7 { value += 16; reasons.append("Published within 7 days") }
            else if days <= 21 { value += 12; reasons.append("Published within 3 weeks") }
            else if days <= 45 { value += 7; reasons.append("Recent application") }
        }
        if decision != nil && status == "Approved" { value += 3 }
        reasons.append("No contractor named in public summary")
        reasons.append("Territory: \(city)")
        return (min(99, max(20, value)), Array(reasons.prefix(6)))
    }

    private func likelyWork(for proposal: String, category: OpportunityCategory) -> [String] {
        let s = proposal.lowercased(); var work: [String] = []
        func add(_ c: Bool,_ t: String){ if c && !work.contains(t){ work.append(t) } }
        add(s.contains("dormer"),"Dormer roof and weathering"); add(s.contains("rooflight") || s.contains("roof light"),"Rooflight installation")
        add(s.contains("slate"),"Slate roofing"); add(s.contains("tile"),"Tiled roofing"); add(s.contains("chimney"),"Chimney / leadwork")
        add(s.contains("solar"),"Solar roof integration"); add(s.contains("flat roof"),"Flat-roof system"); add(s.contains("pitched roof"),"Pitched roof")
        if work.isEmpty {
            switch category { case .lofts: work=["Roof alteration","Weathering / flashing","Insulation"]; case .extensions: work=["Extension roof","Fascia / guttering","Leadwork"]; case .newBuilds: work=["Complete roof package","Rainwater system","Roof coverings"]; default: work=["Roofing works","Flashings / weathering","Rainwater goods"] }
        }
        return Array(work.prefix(4))
    }

    private func estimatedValue(for category: OpportunityCategory, proposal: String) -> String {
        let s = proposal.lowercased()
        if category == .newBuilds { return (s.contains("dwellings") || s.contains("houses") || s.contains("apartments")) ? "£250k–£1m+" : "£120k–£300k" }
        if category == .lofts { return "£30k–£70k" }
        if category == .extensions { return (s.contains("two storey") || s.contains("two-storey")) ? "£60k–£140k" : "£25k–£80k" }
        if s.contains("replacement roof") || s.contains("re-roof") || s.contains("reroof") { return "£8k–£30k" }
        return "£5k–£35k"
    }
    private func midpointValue(for category: OpportunityCategory) -> Int { switch category { case .newBuilds: 210_000; case .lofts: 50_000; case .extensions: 55_000; case .roofing,.all: 20_000 } }

    private func statusText(decision: String?, decisionDate: Date?) -> String {
        let s = clean(decision).uppercased(); if s.contains("REFUS") || s.contains("DECLIN") || s.contains("DISMISS") { return "Refused" }
        if s.contains("WITHDRAW") { return "Withdrawn" }; if s.contains("INVALID") { return "Invalid" }
        if s.contains("GRANT") || s.contains("APPROV") || s.contains("PERMIT") { return "Approved" }
        if decisionDate != nil { return "Decided" }; return "Submitted"
    }

    private func clean(_ value: String?) -> String { (value ?? "").trimmingCharacters(in: .whitespacesAndNewlines) }
    private func date(fromMilliseconds value: Double?) -> Date? { guard let value, value > 0 else { return nil }; return Date(timeIntervalSince1970: value / 1000) }
    private func parseISODate(_ raw: String?) -> Date? { guard let raw, !raw.isEmpty else { return nil }; let f=DateFormatter(); f.locale=Locale(identifier:"en_US_POSIX"); f.dateFormat="yyyy-MM-dd"; return f.date(from:raw) }
    private func relativeDate(_ date: Date?) -> String { guard let date else { return "Live feed" }; let f=RelativeDateTimeFormatter(); f.unitsStyle = .short; return f.localizedString(for: date, relativeTo: Date()) }

    private func extractPostcode(from address: String) -> String {
        let pattern = #"\b(?:BD|LS|HX|HD|WF)\d{1,2}[A-Z]?\s*\d[A-Z]{2}\b"#
        guard let r=try? NSRegularExpression(pattern:pattern,options:.caseInsensitive) else { return "" }; let range=NSRange(address.startIndex...,in:address)
        guard let m=r.firstMatch(in:address,range:range), let sr=Range(m.range,in:address) else { return "" }; return String(address[sr]).uppercased()
    }
    private func isWestYorkshirePostcode(_ postcode: String) -> Bool { ["BD","LS","HX","HD","WF"].contains { postcode.hasPrefix($0) } }
    private func cityFor(postcode: String, address: String) -> String {
        if postcode.hasPrefix("BD") { return "Bradford" }; if postcode.hasPrefix("LS") { return "Leeds" }; if postcode.hasPrefix("HX") { return "Halifax" }; if postcode.hasPrefix("HD") { return "Huddersfield" }; if postcode.hasPrefix("WF") { return "Wakefield" }
        let a=address.lowercased(); if a.contains("halifax") { return "Halifax" }; if a.contains("huddersfield") { return "Huddersfield" }; if a.contains("leeds") { return "Leeds" }; if a.contains("wakefield") { return "Wakefield" }; return "Bradford"
    }
    private func extractArea(from address:String, postcode:String)->String { let p=address.split(separator:",").map{$0.trimmingCharacters(in:.whitespacesAndNewlines)}.filter{!$0.isEmpty}; if p.count>=2 { let c=p[p.count-2]; if c.count<=30 { return c } }; return cityFor(postcode:postcode,address:address) }
    private func normalizedBradfordURL(_ raw:String?,key:String?)->String? { let c=clean(raw); if c.hasPrefix("http://") || c.hasPrefix("https://") { return c }; let k=clean(key); guard !k.isEmpty else{return nil}; return "https://planning.bradford.gov.uk/online-applications/applicationDetails.do?keyVal=\(k.addingPercentEncoding(withAllowedCharacters:.urlQueryAllowed) ?? k)&activeTab=summary" }
    private func centroid(_ geometry:ArcGISGeometry?)->(lat:Double,lon:Double)? { guard let ring=geometry?.rings?.first else{return nil}; let v=ring.filter{$0.count>=2}; guard !v.isEmpty else{return nil}; return (v.reduce(0){$0+$1[1]}/Double(v.count),v.reduce(0){$0+$1[0]}/Double(v.count)) }
    private func pointCoordinate(_ raw:String?)->(lat:Double,lon:Double)? { guard let raw else{return nil}; let nums=raw.replacingOccurrences(of:"POINT",with:"").replacingOccurrences(of:"(",with:"").replacingOccurrences(of:")",with:"").split(separator:" ").compactMap{Double($0)}; guard nums.count>=2 else{return nil}; return (nums[1],nums[0]) }
    private func haversineMiles(lat1:Double,lon1:Double,lat2:Double,lon2:Double)->Double { let r=3958.7613,p1=lat1 * .pi / 180,p2=lat2 * .pi / 180,dp=(lat2 - lat1) * .pi / 180,dl=(lon2 - lon1) * .pi / 180; let a=sin(dp/2)*sin(dp/2)+cos(p1)*cos(p2)*sin(dl/2)*sin(dl/2); return r*2*atan2(sqrt(a),sqrt(1-a)) }

    func requestNotifications() async { do { notificationsEnabled = try await UNUserNotificationCenter.current().requestAuthorization(options:[.alert,.sound,.badge]) } catch { notificationsEnabled = false } }
    private func refreshNotificationState() async { let s = await UNUserNotificationCenter.current().notificationSettings(); notificationsEnabled = s.authorizationStatus == .authorized || s.authorizationStatus == .provisional }
    private func notifyForNewHighScores(in items:[Opportunity]) async { guard notificationsEnabled else{return}; for item in items.filter({$0.score>=85}).prefix(3){ let c=UNMutableNotificationContent(); c.title="ZK Radar · \(item.city) · \(item.score)"; c.body="\(item.title)"; c.sound = .default; try? await UNUserNotificationCenter.current().add(UNNotificationRequest(identifier:"radar-\(item.id)",content:c,trigger:nil)) } }

    func propertyOwnerLetter(for item: Opportunity) -> String {
        """
        Dear Property Owner,

        We are contacting you regarding the publicly listed planning application \(item.reference) concerning \(item.title.lowercased()) in \(item.postcode).

        We are a local roofing contractor serving \(item.city) and surrounding areas. The published proposal may involve \(item.likelyWork.joined(separator: ", ").lowercased()).

        If you are currently obtaining quotations and have not yet appointed a roofing contractor, we would be happy to discuss the roofing element and provide a no-obligation quotation.

        If you have already appointed someone or this is not relevant, please disregard this letter.

        Kind regards,
        [Roofing company name]
        [Telephone number]
        [Email / website]
        """
    }

    func agentMessage(for item: Opportunity) -> String {
        """
        Hi,

        I am contacting you regarding planning application \(item.reference) for \(item.title) in \(item.postcode).

        We are a roofing contractor covering \(item.city) and can assist with the roofing package, including \(item.likelyWork.joined(separator: ", ").lowercased()).

        If you are the architect or agent handling this project, could you let me know whether the roofing package is still open for quotations? If another contractor has already been appointed, no further action is needed.

        Kind regards,
        [Roofing company name]
        [Contact details]
        """
    }

    func rooferSalesMessage(for item: Opportunity) -> String {
        """
        Hi,

        I run ZK Opportunity Radar and found a fresh roofing opportunity in \(item.city) (\(item.postcode)).

        • Score: \(item.score)/99
        • Planning ref: \(item.reference)
        • Proposal: \(item.title)
        • Likely roofing work: \(item.likelyWork.joined(separator: ", "))
        • Status: \(item.status)
        • Contractor check: no contractor is named in the public application summary

        I can supply filtered opportunities like this for your local territory so you do not have to search planning portals manually.

        Regards,
        ZK Opportunity Radar
        [Your contact details]
        """
    }
}
