# ZK Opportunity Radar v0.3.1 — West Yorkshire

Native SwiftUI roofing lead radar.

## Changes
- West Yorkshire scan using the official Planning Data API plus Bradford Council GIS.
- Focus areas: Bradford, Leeds, Halifax/Calderdale, Huddersfield/Kirklees and Wakefield based on West Yorkshire postcode coverage.
- Stricter freshness rules: submitted applications generally <=60 days; recently approved applications must remain inside the buying window.
- Rejects refused, withdrawn, decided/admin-only and weak roofing matches.
- Rejects applications where a contractor/builder is explicitly named in the public application summary.
- Displays a best-effort “no contractor named” check; it cannot prove nobody was appointed privately.
- Nearby Roofer Finder using Apple Maps/MapKit, no third-party API key required.
- Separate Roofer Sales Message, Property Owner Letter and Agent/Architect Message.
- User-supplied radar/house logo forced as app icon and in-app brand image.
