import Foundation

enum OpportunityCategory: String, CaseIterable, Identifiable, Codable {
    case all = "All", roofing = "Roofing", extensions = "Extensions", lofts = "Lofts", newBuilds = "New Builds"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .all: return "scope"
        case .roofing: return "house.lodge.fill"
        case .extensions: return "hammer.fill"
        case .lofts: return "stairs"
        case .newBuilds: return "building.2.fill"
        }
    }
}

struct Opportunity: Identifiable, Hashable {
    let id: UUID
    let title, area, postcode: String
    let distanceMiles: Double
    let category: OpportunityCategory
    let score: Int
    let status, discovered, estimatedValue, description: String
    let likelyWork, reasons: [String]
    let reference, source: String

    static let demo: [Opportunity] = [
        Opportunity(id: UUID(uuidString: "718DDAE3-195E-4AFB-AB66-001122334401")!, title: "Two-storey side and rear extension", area: "Bradford", postcode: "BD4", distanceMiles: 3.2, category: .roofing, score: 91, status: "Approved", discovered: "18 min ago", estimatedValue: "£45k–£75k", description: "Two-storey side extension and single-storey rear extension with a new pitched roof and rooflights.", likelyWork: ["New pitched roof", "Rooflights", "Guttering", "Leadwork"], reasons: ["Approved project", "Strong roofing match", "Recently discovered", "Within selected radius"], reference: "DEMO/BD4/2401", source: "Demonstration record"),
        Opportunity(id: UUID(uuidString: "718DDAE3-195E-4AFB-AB66-001122334402")!, title: "Hip-to-gable loft conversion", area: "Shipley", postcode: "BD18", distanceMiles: 5.7, category: .lofts, score: 86, status: "Submitted", discovered: "1 hr ago", estimatedValue: "£35k–£55k", description: "Hip-to-gable roof alteration, rear dormer and installation of three front rooflights.", likelyWork: ["Roof alteration", "Dormer covering", "Rooflights", "Insulation"], reasons: ["High-value loft work", "Multiple roofing elements", "Local project"], reference: "DEMO/BD18/2402", source: "Demonstration record"),
        Opportunity(id: UUID(uuidString: "718DDAE3-195E-4AFB-AB66-001122334403")!, title: "Detached dwelling with garage", area: "Pudsey", postcode: "LS28", distanceMiles: 7.9, category: .newBuilds, score: 82, status: "Approved", discovered: "Today", estimatedValue: "£180k–£260k", description: "Construction of one detached home with integral garage following demolition of an outbuilding.", likelyWork: ["Complete roof structure", "Tiles", "Rainwater system", "Garage roof"], reasons: ["Approved new build", "Large contract potential", "Clear roof package"], reference: "DEMO/LS28/2403", source: "Demonstration record"),
        Opportunity(id: UUID(uuidString: "718DDAE3-195E-4AFB-AB66-001122334404")!, title: "Single-storey kitchen extension", area: "Bingley", postcode: "BD16", distanceMiles: 8.4, category: .extensions, score: 77, status: "Approved", discovered: "Yesterday", estimatedValue: "£25k–£40k", description: "Rear kitchen extension with a shallow pitched tiled roof and two roof windows.", likelyWork: ["Extension roof", "Two roof windows", "Fascia and guttering"], reasons: ["Approved project", "Simple delivery", "Good local fit"], reference: "DEMO/BD16/2404", source: "Demonstration record"),
        Opportunity(id: UUID(uuidString: "718DDAE3-195E-4AFB-AB66-001122334405")!, title: "Replacement roof and solar panels", area: "Keighley", postcode: "BD21", distanceMiles: 11.8, category: .roofing, score: 74, status: "Submitted", discovered: "Yesterday", estimatedValue: "£18k–£30k", description: "Replacement slate roof covering with integrated solar panels and repairs to two chimney stacks.", likelyWork: ["Slate replacement", "Solar integration", "Chimney repair", "Scaffolding"], reasons: ["Direct roofing requirement", "Clear scope", "Moderate travel distance"], reference: "DEMO/BD21/2405", source: "Demonstration record")
    ]
}
