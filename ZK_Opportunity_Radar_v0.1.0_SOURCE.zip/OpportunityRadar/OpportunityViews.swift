import SwiftUI

struct OpportunityFeedView: View {
    @EnvironmentObject private var store: OpportunityStore
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    PageTitle(eyebrow: "Bradford · 15 mile radius", title: "Opportunities")
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass").foregroundStyle(RadarTheme.muted)
                        TextField("Search area, postcode or project", text: $store.searchText).font(.system(size: 13, weight: .semibold, design: .rounded))
                    }.padding(13).background(RadarTheme.surface).clipShape(RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(RadarTheme.border))

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(OpportunityCategory.allCases) { item in
                                Button { store.category = item } label: {
                                    Label(item.rawValue, systemImage: item.icon).font(.system(size: 10, weight: .black, design: .rounded))
                                        .padding(.horizontal, 11).padding(.vertical, 9)
                                        .foregroundStyle(store.category == item ? Color.black : RadarTheme.soft)
                                        .background(store.category == item ? RadarTheme.green : RadarTheme.surface).clipShape(Capsule())
                                }
                            }
                        }
                    }

                    HStack {
                        Text("\(store.filtered.count) MATCHES").font(.system(size: 10, weight: .black, design: .rounded)).tracking(1).foregroundStyle(RadarTheme.muted)
                        Spacer(); StatusPill(text: "Demo feed", color: RadarTheme.amber)
                    }

                    LazyVStack(spacing: 12) {
                        ForEach(store.filtered) { item in
                            NavigationLink(value: item) { OpportunityRow(opportunity: item) }.buttonStyle(.plain)
                        }
                    }
                }.padding(16).padding(.bottom, 24)
            }
            .background(RadarTheme.background.ignoresSafeArea())
            .navigationDestination(for: Opportunity.self) { OpportunityDetailView(opportunity: $0) }
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

struct OpportunityRow: View {
    @EnvironmentObject private var store: OpportunityStore
    let opportunity: Opportunity
    var body: some View {
        RadarCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top) {
                    ScoreBadge(score: opportunity.score)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(opportunity.title).font(.system(size: 15, weight: .bold, design: .rounded)).foregroundStyle(.white).multilineTextAlignment(.leading)
                        Text("\(opportunity.area) · \(opportunity.postcode) · \(String(format: "%.1f", opportunity.distanceMiles)) mi")
                            .font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundStyle(RadarTheme.muted)
                    }
                    Spacer(minLength: 4)
                    Button { store.toggleSaved(opportunity) } label: {
                        Image(systemName: store.savedIDs.contains(opportunity.id) ? "bookmark.fill" : "bookmark")
                            .foregroundStyle(store.savedIDs.contains(opportunity.id) ? RadarTheme.green : RadarTheme.muted).padding(4)
                    }.buttonStyle(.plain)
                }
                HStack {
                    StatusPill(text: opportunity.status, color: opportunity.status == "Approved" ? RadarTheme.green : RadarTheme.cyan)
                    StatusPill(text: opportunity.category.rawValue, color: RadarTheme.soft)
                    Spacer(); Text(opportunity.discovered).font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(RadarTheme.muted)
                }
                Divider().overlay(RadarTheme.border)
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("ESTIMATED PROJECT").font(.system(size: 8, weight: .black, design: .rounded)).tracking(0.8).foregroundStyle(RadarTheme.muted)
                        Text(opportunity.estimatedValue).font(.system(size: 16, weight: .black, design: .rounded)).foregroundStyle(RadarTheme.amber)
                    }
                    Spacer(); Image(systemName: "chevron.right").font(.system(size: 12, weight: .black)).foregroundStyle(RadarTheme.green)
                }
            }
        }
    }
}

struct ScoreBadge: View {
    let score: Int
    private var color: Color { score >= 85 ? RadarTheme.green : score >= 75 ? RadarTheme.amber : RadarTheme.muted }
    var body: some View {
        VStack(spacing: 0) {
            Text("\(score)").font(.system(size: 18, weight: .black, design: .rounded))
            Text("SCORE").font(.system(size: 6, weight: .black, design: .rounded)).tracking(0.6)
        }.foregroundStyle(color).frame(width: 48, height: 48).background(color.opacity(0.09))
            .clipShape(RoundedRectangle(cornerRadius: 13)).overlay(RoundedRectangle(cornerRadius: 13).stroke(color.opacity(0.35)))
    }
}

struct OpportunityDetailView: View {
    @EnvironmentObject private var store: OpportunityStore
    let opportunity: Opportunity
    @State private var showLetter = false
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                HStack(alignment: .top) {
                    ScoreBadge(score: opportunity.score)
                    VStack(alignment: .leading, spacing: 5) {
                        Text(opportunity.title).font(.system(size: 23, weight: .black, design: .rounded))
                        Text("\(opportunity.area) · \(opportunity.postcode)").foregroundStyle(RadarTheme.muted)
                    }
                    Spacer()
                    Button { store.toggleSaved(opportunity) } label: {
                        Image(systemName: store.savedIDs.contains(opportunity.id) ? "bookmark.fill" : "bookmark").font(.title3).foregroundStyle(RadarTheme.green)
                    }
                }
                HStack { StatusPill(text: opportunity.status, color: RadarTheme.green); StatusPill(text: opportunity.discovered, color: RadarTheme.cyan) }
                DetailCard(title: "ZK ANALYSIS", icon: "sparkles") {
                    Text(opportunity.description).font(.system(size: 14, weight: .medium, design: .rounded)).foregroundStyle(RadarTheme.soft)
                }
                HStack(spacing: 10) {
                    InfoTile(label: "VALUE", value: opportunity.estimatedValue, color: RadarTheme.amber)
                    InfoTile(label: "DISTANCE", value: String(format: "%.1f mi", opportunity.distanceMiles), color: RadarTheme.cyan)
                }
                DetailCard(title: "LIKELY WORK", icon: "hammer.fill") {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(opportunity.likelyWork, id: \.self) { Text($0).font(.system(size: 12, weight: .bold, design: .rounded)).foregroundStyle(RadarTheme.soft) }
                    }
                }
                DetailCard(title: "WHY IT SCORED", icon: "chart.bar.fill") {
                    VStack(alignment: .leading, spacing: 9) {
                        ForEach(opportunity.reasons, id: \.self) { Label($0, systemImage: "checkmark.circle.fill").font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(RadarTheme.soft) }
                    }
                }
                DetailCard(title: "SOURCE", icon: "doc.text.fill") {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(opportunity.reference).font(.system(size: 13, weight: .bold, design: .monospaced))
                        Text(opportunity.source).font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundStyle(RadarTheme.amber)
                    }
                }
                Button { showLetter = true } label: {
                    Label("CREATE INTRODUCTION LETTER", systemImage: "envelope.fill").font(.system(size: 12, weight: .black, design: .rounded)).foregroundStyle(.black)
                        .frame(maxWidth: .infinity).padding(.vertical, 15).background(RadarTheme.glow).clipShape(RoundedRectangle(cornerRadius: 15))
                }
            }.padding(16).padding(.bottom, 24)
        }
        .background(RadarTheme.background.ignoresSafeArea()).navigationTitle("Opportunity").navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showLetter) { LetterView(opportunity: opportunity).presentationDetents([.medium, .large]) }
    }
}

private struct DetailCard<Content: View>: View {
    let title, icon: String
    @ViewBuilder var content: Content
    var body: some View {
        RadarCard { VStack(alignment: .leading, spacing: 12) {
            Label(title, systemImage: icon).font(.system(size: 10, weight: .black, design: .rounded)).tracking(1).foregroundStyle(RadarTheme.green)
            content
        }.frame(maxWidth: .infinity, alignment: .leading) }
    }
}

private struct InfoTile: View {
    let label, value: String; let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.system(size: 8, weight: .black, design: .rounded)).tracking(1).foregroundStyle(RadarTheme.muted)
            Text(value).font(.system(size: 17, weight: .black, design: .rounded)).foregroundStyle(color)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(RadarTheme.surface)
            .clipShape(RoundedRectangle(cornerRadius: 15)).overlay(RoundedRectangle(cornerRadius: 15).stroke(RadarTheme.border))
    }
}

private struct LetterView: View {
    @EnvironmentObject private var store: OpportunityStore
    @Environment(\.dismiss) private var dismiss
    let opportunity: Opportunity
    var body: some View {
        NavigationStack {
            ScrollView {
                Text(store.letter(for: opportunity)).font(.system(size: 14, weight: .medium, design: .rounded)).foregroundStyle(RadarTheme.soft)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(16).background(RadarTheme.surface).clipShape(RoundedRectangle(cornerRadius: 16)).padding(16)
            }
            .background(RadarTheme.background.ignoresSafeArea()).navigationTitle("Introduction Letter").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Close") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { ShareLink(item: store.letter(for: opportunity)) { Image(systemName: "square.and.arrow.up") } }
            }
        }
    }
}
