import Foundation
import Combine
import UserNotifications

@MainActor
final class OpportunityStore: ObservableObject {
    @Published var opportunities = Opportunity.demo
    @Published var savedIDs: Set<UUID> = []
    @Published var category: OpportunityCategory = .all
    @Published var searchText = ""
    @Published var radius = 15.0
    @Published var isScanning = false
    @Published var scanMessage = "Demo feed ready"
    @Published var notificationsEnabled = false

    var filtered: [Opportunity] {
        opportunities.filter { category == .all || $0.category == category }
            .filter { $0.distanceMiles <= radius }
            .filter { searchText.isEmpty || $0.title.localizedCaseInsensitiveContains(searchText) || $0.area.localizedCaseInsensitiveContains(searchText) || $0.postcode.localizedCaseInsensitiveContains(searchText) }
            .sorted { $0.score > $1.score }
    }
    var saved: [Opportunity] { opportunities.filter { savedIDs.contains($0.id) }.sorted { $0.score > $1.score } }

    func toggleSaved(_ item: Opportunity) {
        if savedIDs.contains(item.id) { savedIDs.remove(item.id) } else { savedIDs.insert(item.id) }
    }
    func scan() async {
        guard !isScanning else { return }
        isScanning = true; scanMessage = "Checking local sources…"
        try? await Task.sleep(for: .seconds(1.2)); scanMessage = "Analysing project fit…"
        try? await Task.sleep(for: .seconds(1.1)); scanMessage = "5 demo opportunities ranked"; isScanning = false
    }
    func requestNotifications() async {
        do { notificationsEnabled = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) }
        catch { notificationsEnabled = false }
    }
    func letter(for item: Opportunity) -> String {
        """
        Dear Property Owner,

        We noticed the recently published planning proposal concerning \(item.title.lowercased()) in \(item.postcode).

        We are a local roofing contractor serving \(item.area) and the surrounding area. Our team can assist with \(item.likelyWork.joined(separator: ", ").lowercased()).

        If you have not yet appointed a roofing contractor, we would be pleased to discuss the project and provide a no-obligation quotation.

        Kind regards,
        [Your company name]
        [Telephone number]
        """
    }
}
