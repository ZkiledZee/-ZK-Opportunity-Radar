import SwiftUI

struct RootView: View {
    @State private var selectedTab = 0
    var body: some View {
        TabView(selection: $selectedTab) {
            RadarHomeView(selectedTab: $selectedTab).tag(0).tabItem { Label("Radar", systemImage: "scope") }
            OpportunityFeedView().tag(1).tabItem { Label("Opportunities", systemImage: "bolt.fill") }
            SavedView().tag(2).tabItem { Label("Saved", systemImage: "bookmark.fill") }
            SettingsView().tag(3).tabItem { Label("Settings", systemImage: "slider.horizontal.3") }
        }.tint(RadarTheme.green)
    }
}
