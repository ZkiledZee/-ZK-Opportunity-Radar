import SwiftUI

struct SavedView: View {
    @EnvironmentObject private var store: OpportunityStore
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    PageTitle(eyebrow: "Your shortlist", title: "Saved")
                    if store.saved.isEmpty {
                        RadarCard {
                            VStack(spacing: 12) {
                                Image(systemName: "bookmark.slash").font(.system(size: 34, weight: .light)).foregroundStyle(RadarTheme.green)
                                Text("No saved opportunities").font(.system(size: 17, weight: .bold, design: .rounded))
                                Text("Tap the bookmark on a project to build your shortlist.").font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(RadarTheme.muted).multilineTextAlignment(.center)
                            }.frame(maxWidth: .infinity).padding(.vertical, 35)
                        }
                    } else {
                        ForEach(store.saved) { item in NavigationLink(value: item) { OpportunityRow(opportunity: item) }.buttonStyle(.plain) }
                    }
                }.padding(16)
            }
            .background(RadarTheme.background.ignoresSafeArea())
            .navigationDestination(for: Opportunity.self) { OpportunityDetailView(opportunity: $0) }
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: OpportunityStore
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    PageTitle(eyebrow: "Scanner configuration", title: "Settings")
                    RadarCard {
                        VStack(alignment: .leading, spacing: 16) {
                            Header("SEARCH AREA", icon: "location.fill")
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("Bradford").font(.system(size: 16, weight: .bold, design: .rounded))
                                    Text("West Yorkshire").font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundStyle(RadarTheme.muted)
                                }
                                Spacer(); StatusPill(text: "Active", color: RadarTheme.green)
                            }
                            Divider().overlay(RadarTheme.border)
                            HStack { Text("Radius"); Spacer(); Text("\(Int(store.radius)) miles").foregroundStyle(RadarTheme.green).fontWeight(.bold) }
                            Slider(value: $store.radius, in: 5...30, step: 5).tint(RadarTheme.green)
                        }
                    }
                    RadarCard {
                        VStack(alignment: .leading, spacing: 14) {
                            Header("TRADE PROFILE", icon: "hammer.fill")
                            Label("Roofing contractor", systemImage: "house.lodge.fill").font(.system(size: 15, weight: .bold, design: .rounded)).foregroundStyle(RadarTheme.green)
                            Text("Extensions · Lofts · New builds").font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundStyle(RadarTheme.muted)
                        }
                    }
                    RadarCard {
                        VStack(alignment: .leading, spacing: 14) {
                            Header("ALERTS", icon: "bell.fill")
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("High-score notifications").font(.system(size: 14, weight: .bold, design: .rounded))
                                    Text(store.notificationsEnabled ? "Permission enabled" : "Notify for scores of 85+").font(.system(size: 10, weight: .semibold, design: .rounded)).foregroundStyle(RadarTheme.muted)
                                }
                                Spacer()
                                Button(store.notificationsEnabled ? "ENABLED" : "ENABLE") { Task { await store.requestNotifications() } }
                                    .font(.system(size: 9, weight: .black, design: .rounded)).foregroundStyle(store.notificationsEnabled ? RadarTheme.green : .black)
                                    .padding(.horizontal, 11).padding(.vertical, 8).background(store.notificationsEnabled ? RadarTheme.green.opacity(0.1) : RadarTheme.green).clipShape(Capsule())
                            }
                        }
                    }
                    RadarCard {
                        VStack(alignment: .leading, spacing: 9) {
                            Header("BUILD STATUS", icon: "wrench.and.screwdriver.fill")
                            Label("Interface and offline demo engine operational", systemImage: "checkmark.circle.fill").foregroundStyle(RadarTheme.green)
                            Label("Live cloud scanner not connected in v0.1", systemImage: "clock.fill").foregroundStyle(RadarTheme.amber)
                            Text("No opportunity displayed in this build represents a real homeowner or live planning application.")
                                .font(.system(size: 11, weight: .medium, design: .rounded)).foregroundStyle(RadarTheme.muted)
                        }.font(.system(size: 12, weight: .semibold, design: .rounded))
                    }
                    Text("ZK OPPORTUNITY RADAR · VERSION 0.1.0").font(.system(size: 9, weight: .black, design: .rounded)).tracking(1).foregroundStyle(RadarTheme.muted).frame(maxWidth: .infinity)
                }.padding(16).padding(.bottom, 24)
            }
            .background(RadarTheme.background.ignoresSafeArea()).toolbar(.hidden, for: .navigationBar)
        }
    }
}

private struct Header: View {
    let title, icon: String
    init(_ title: String, icon: String) { self.title = title; self.icon = icon }
    var body: some View {
        Label(title, systemImage: icon).font(.system(size: 10, weight: .black, design: .rounded)).tracking(1).foregroundStyle(RadarTheme.green)
    }
}
