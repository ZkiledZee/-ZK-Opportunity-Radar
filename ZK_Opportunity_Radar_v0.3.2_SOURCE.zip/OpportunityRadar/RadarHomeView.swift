import SwiftUI

struct RadarHomeView: View {
    @EnvironmentObject private var store: OpportunityStore
    @Binding var selectedTab: Int

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("ZK").font(.system(size: 13, weight: .black, design: .rounded)).tracking(3).foregroundStyle(RadarTheme.green)
                            Text("OPPORTUNITY RADAR").font(.system(size: 20, weight: .black, design: .rounded))
                        }
                        Spacer()
                        StatusPill(text: store.isScanning ? "SCANNING" : (store.feedIsLive ? "LIVE" : "READY"), color: store.feedIsLive || store.isScanning ? RadarTheme.green : RadarTheme.amber)
                    }

                    RadarVisual().frame(height: 250)

                    VStack(spacing: 12) {
                        Text(store.scanMessage).font(.system(size: 13, weight: .bold, design: .rounded)).foregroundStyle(RadarTheme.soft)
                        Button { Task { await store.scan() } } label: {
                            Label(store.isScanning ? "SCANNING" : "SCAN NOW", systemImage: store.isScanning ? "wave.3.right" : "scope")
                                .font(.system(size: 12, weight: .black, design: .rounded)).tracking(1).foregroundStyle(.black)
                                .frame(maxWidth: .infinity).padding(.vertical, 14).background(RadarTheme.glow)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                        }.disabled(store.isScanning)
                    }

                    HStack(spacing: 10) {
                        StatTile(value: "\(store.filtered.count)", label: "Qualified", color: RadarTheme.green)
                        StatTile(value: "\(store.highScoreCount)", label: "Hot leads", color: RadarTheme.cyan)
                        StatTile(value: store.potentialValueText, label: "Potential", color: RadarTheme.amber)
                    }

                    if let top = store.filtered.first {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("TOP OPPORTUNITY").font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.3).foregroundStyle(RadarTheme.muted)
                                Spacer()
                                Button("VIEW ALL") { selectedTab = 1 }.font(.system(size: 10, weight: .black, design: .rounded)).foregroundStyle(RadarTheme.green)
                            }
                            OpportunityRow(opportunity: top)
                        }
                    }

                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: store.feedIsLive ? "checkmark.seal.fill" : "wifi.exclamationmark").foregroundStyle(store.feedIsLive ? RadarTheme.green : RadarTheme.amber)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(store.feedIsLive ? "LIVE WEST YORKSHIRE DATA" : "LIVE FEED NOT CONNECTED")
                                .font(.system(size: 10, weight: .black, design: .rounded)).tracking(0.8)
                            Text(store.feedIsLive ? "Fresh applications are pulled from official/public planning feeds for West Yorkshire coverage, with Bradford Council GIS as a direct council source. Old, refused, admin-only and contractor-named summaries are removed. Public summaries cannot prove that nobody was appointed privately." : (store.lastError ?? "Tap Scan Now to connect to the live council feed."))
                                .font(.system(size: 11, weight: .medium, design: .rounded)).foregroundStyle(RadarTheme.muted)
                        }
                    }
                    .padding(13).background((store.feedIsLive ? RadarTheme.green : RadarTheme.amber).opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .padding(.horizontal, 16).padding(.top, 18).padding(.bottom, 30)
            }
            .background(RadarTheme.background.ignoresSafeArea()).toolbar(.hidden, for: .navigationBar)
        }
    }
}

private struct StatTile: View {
    let value, label: String
    let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(value).font(.system(size: 19, weight: .black, design: .rounded)).foregroundStyle(color).lineLimit(1).minimumScaleFactor(0.65)
            Text(label.uppercased()).font(.system(size: 8, weight: .black, design: .rounded)).tracking(0.7).foregroundStyle(RadarTheme.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading).padding(12).background(RadarTheme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(RadarTheme.border))
    }
}

private struct RadarVisual: View {
    @State private var rotation = 0.0
    @State private var pulse = false
    @State private var corePulse = false
    @State private var orbit = 0.0
    private let points = [CGSize(width: 68, height: -56), CGSize(width: -74, height: 34), CGSize(width: 44, height: 82), CGSize(width: -35, height: -91), CGSize(width: 92, height: 19)]

    var body: some View {
        ZStack {
            ForEach([0.34, 0.58, 0.82, 1.0], id: \.self) { scale in
                Circle().stroke(RadarTheme.green.opacity(0.16), lineWidth: 1).scaleEffect(scale)
            }
            Rectangle().fill(RadarTheme.green.opacity(0.12)).frame(width: 1)
            Rectangle().fill(RadarTheme.green.opacity(0.12)).frame(height: 1)

            Circle().trim(from: 0, to: 0.23)
                .stroke(
                    AngularGradient(colors: [RadarTheme.green.opacity(0), RadarTheme.green], center: .center),
                    style: StrokeStyle(lineWidth: 4, lineCap: .round)
                )
                .rotationEffect(.degrees(rotation))
                .shadow(color: RadarTheme.green, radius: 10)

            ForEach(0..<5, id: \.self) { index in
                Circle()
                    .fill(index < 2 ? RadarTheme.green : RadarTheme.cyan)
                    .frame(width: index < 2 ? 9 : 6, height: index < 2 ? 9 : 6)
                    .shadow(color: RadarTheme.green, radius: 8)
                    .offset(points[index])
                    .scaleEffect(pulse && index < 2 ? 1.35 : 0.9)
            }

            // Animated scanner core. No text is shown in the centre.
            ZStack {
                Circle()
                    .fill(RadarTheme.background.opacity(0.96))
                    .frame(width: 78, height: 78)
                    .overlay(Circle().stroke(RadarTheme.green.opacity(0.65), lineWidth: 1.5))

                Circle()
                    .stroke(RadarTheme.green.opacity(0.28), lineWidth: 2)
                    .frame(width: 48, height: 48)
                    .scaleEffect(corePulse ? 1.35 : 0.72)
                    .opacity(corePulse ? 0.05 : 0.85)

                Circle()
                    .fill(RadarTheme.green.opacity(0.18))
                    .frame(width: 32, height: 32)
                    .scaleEffect(corePulse ? 1.15 : 0.78)

                Circle()
                    .fill(RadarTheme.green)
                    .frame(width: 10, height: 10)
                    .shadow(color: RadarTheme.green, radius: 10)

                Circle()
                    .fill(RadarTheme.cyan)
                    .frame(width: 6, height: 6)
                    .offset(y: -27)
                    .rotationEffect(.degrees(orbit))
                    .shadow(color: RadarTheme.cyan, radius: 6)
            }
        }
        .padding(10)
        .onAppear {
            withAnimation(.linear(duration: 5).repeatForever(autoreverses: false)) { rotation = 360 }
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) { pulse = true }
            withAnimation(.easeOut(duration: 1.45).repeatForever(autoreverses: false)) { corePulse = true }
            withAnimation(.linear(duration: 2.4).repeatForever(autoreverses: false)) { orbit = 360 }
        }
    }
}
