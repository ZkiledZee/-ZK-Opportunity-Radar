import SwiftUI

enum RadarTheme {
    static let background = Color(red: 0.015, green: 0.020, blue: 0.026)
    static let surface = Color(red: 0.030, green: 0.044, blue: 0.052)
    static let surfaceRaised = Color(red: 0.043, green: 0.061, blue: 0.071)
    static let border = Color(red: 0.115, green: 0.190, blue: 0.197)
    static let green = Color(red: 0.13, green: 0.94, blue: 0.62)
    static let cyan = Color(red: 0.22, green: 0.80, blue: 1.00)
    static let amber = Color(red: 1.00, green: 0.72, blue: 0.24)
    static let muted = Color(red: 0.56, green: 0.64, blue: 0.66)
    static let soft = Color(red: 0.75, green: 0.81, blue: 0.82)
    static let glow = LinearGradient(colors: [green, cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
}

struct RadarCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(15)
            .background(LinearGradient(colors: [RadarTheme.surfaceRaised, RadarTheme.surface], startPoint: .topLeading, endPoint: .bottomTrailing))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(RadarTheme.border, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

struct StatusPill: View {
    let text: String
    let color: Color

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 6, height: 6)
            Text(text.uppercased()).font(.system(size: 9, weight: .black, design: .rounded)).tracking(0.7)
        }
        .foregroundStyle(color).padding(.horizontal, 9).padding(.vertical, 6)
        .background(color.opacity(0.10)).clipShape(Capsule()).overlay(Capsule().stroke(color.opacity(0.30)))
    }
}

struct PageTitle: View {
    let eyebrow: String
    let title: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(eyebrow.uppercased()).font(.system(size: 10, weight: .black, design: .rounded)).tracking(1.5).foregroundStyle(RadarTheme.green)
            Text(title).font(.system(size: 29, weight: .black, design: .rounded)).tracking(-0.8)
        }
    }
}
