import Foundation
import MapKit

@MainActor
final class BusinessFinder: ObservableObject {
    @Published var businesses: [NearbyBusiness] = []
    @Published var isSearching = false
    @Published var errorMessage: String?

    func search(for opportunity: Opportunity) async {
        guard !isSearching else { return }
        isSearching = true; errorMessage = nil; businesses = []
        do {
            let centre: CLLocationCoordinate2D
            if let lat = opportunity.latitude, let lon = opportunity.longitude {
                centre = CLLocationCoordinate2D(latitude: lat, longitude: lon)
            } else {
                let marks = try await CLGeocoder().geocodeAddressString(opportunity.postcode)
                guard let c = marks.first?.location?.coordinate else { throw URLError(.cannotFindHost) }
                centre = c
            }
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = "roofing contractor"
            request.region = MKCoordinateRegion(center: centre, latitudinalMeters: 32000, longitudinalMeters: 32000)
            let response = try await MKLocalSearch(request: request).start()
            businesses = response.mapItems.compactMap { item in
                guard let name = item.name, !name.isEmpty else { return nil }
                let c = item.placemark.coordinate
                let miles = distanceMiles(from: centre, to: c)
                let address = [item.placemark.subThoroughfare, item.placemark.thoroughfare, item.placemark.locality, item.placemark.postalCode].compactMap{$0}.joined(separator: " ")
                return NearbyBusiness(id: "\(name)-\(c.latitude)-\(c.longitude)", name: name, phone: item.phoneNumber, website: item.url?.absoluteString, address: address, distanceMiles: miles)
            }
            .filter { $0.distanceMiles <= 20 }
            .sorted { $0.distanceMiles < $1.distanceMiles }
            .prefix(20).map{$0}
        } catch { errorMessage = error.localizedDescription }
        isSearching = false
    }

    private func distanceMiles(from a: CLLocationCoordinate2D, to b: CLLocationCoordinate2D) -> Double {
        CLLocation(latitude:a.latitude,longitude:a.longitude).distance(from:CLLocation(latitude:b.latitude,longitude:b.longitude)) / 1609.344
    }
}
