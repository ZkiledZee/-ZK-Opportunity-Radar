import SwiftUI

struct RootView: View {
    @EnvironmentObject private var store: OpportunityStore
    @State private var selectedTab = 0
    @State private var didInitialScan = false
    var body: some View {
        TabView(selection: $selectedTab) {
            RadarHomeView(selectedTab: $selectedTab).tag(0).tabItem { Label("Radar", systemImage: "scope") }
            OpportunityFeedView().tag(1).tabItem { Label("Opportunities", systemImage: "bolt.fill") }
            SavedView().tag(2).tabItem { Label("Saved", systemImage: "bookmark.fill") }
            SettingsView().tag(3).tabItem { Label("Settings", systemImage: "slider.horizontal.3") }
        }.tint(RadarTheme.green)
        .task {
            guard !didInitialScan else { return }
            didInitialScan = true
            await store.scan()
        }
    }
}
