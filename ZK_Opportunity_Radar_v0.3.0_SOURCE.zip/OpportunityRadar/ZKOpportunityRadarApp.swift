import SwiftUI

@main
struct ZKOpportunityRadarApp: App {
    @StateObject private var store = OpportunityStore()

    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(store).preferredColorScheme(.dark)
        }
    }
}
